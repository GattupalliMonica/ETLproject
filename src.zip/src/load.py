import sqlalchemy
from sqlalchemy import create_engine

def load(df, db_path):
    engine = create_engine(f'sqlite:///{db_path}')
    df.to_sql('employees', engine, if_exists='replace', index=False)
