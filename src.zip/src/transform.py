def transform(df):
    df['salary'] = df['salary'] * 1.1  # Increase salary by 10%
    df['full_name'] = df['name'].apply(lambda x: x.upper())  # Convert names to uppercase
    df.drop(columns=['name'], inplace=True)
    return df
